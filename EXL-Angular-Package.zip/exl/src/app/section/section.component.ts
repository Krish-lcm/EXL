import { Component, Input, ViewChild } from '@angular/core';
import { Subject } from 'rxjs';
import { TableComponent } from '../table/table.component';
import { Selected } from '../coordinate';

@Component({
  selector: 'app-section',
  templateUrl: './section.component.html',
  styleUrls: ['./section.component.css'],
})
export class SectionComponent {
  _iterate: number;
  _eachSection: any;
  _idx: any;
  _masterList: any;
  _brokerCascadingList: any;
  endVal: string = 'end';
  @Input()
  set iterate(message: number) {
    this._iterate = message;
  }
  get iterate() {
    return this._iterate;
  }
  @Input()
  set eachSection(eachSection: any) {
    this._eachSection = eachSection;
  }
  get eachSection() {
    return this._eachSection;
  }

  @Input()
  set masterList(list: any) {
    this._masterList = list;
  }
  get masterList() {
    return this._masterList;
  }
  @Input()
  set brokerCascadingList(list: any) {
    this._brokerCascadingList = list;
  }
  get brokerCascadingList() {
    return this._brokerCascadingList;
  }
  @Input()
  set selectIdx(selectIdx: any) {
    this._idx = selectIdx;
  }
  get selectIdx() {
    return this._idx;
  }

  @Input() notifierSection: Subject<Selected>;
  value: Selected;
  selectedValue: Selected;

  ngOnInit() {
    
    this.notifierSection.subscribe((data) => (this.value = data));
    this.selectedValue = this.value;
  }

  triggerSectionUpdates() {
    this.tableComponent.triggerModelChanegs(this.value);
  }
 

  getProcessedId(label: string): string {   return 'lbl' + label.toLowerCase().replace(/[^a-z]/g, ''); }
  @ViewChild(TableComponent) tableComponent;
}
