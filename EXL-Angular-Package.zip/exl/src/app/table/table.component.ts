import { AfterViewInit, Component, HostListener, Input } from '@angular/core';
import { EXLPdfServiceService } from '../exlpdf-service-service.service';
import { Common } from '../common';
import { Selected, DropDownVal } from '../coordinate';
import { formatDate } from '@angular/common';
import { Rule, masterListProps, ruleProps, ruleStyleProps } from '../rule';

declare var Appian: any;
@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css'],
})
export class TableComponent implements AfterViewInit {
  _iterateTable: number;
  _eachRow: any;
  _eachSection: any;
  _config: any;
  _masterList: any;
  _brokerCascadingList: any;
  current: string = '';
  public static _currentSelectItem: any;
  public required: boolean = false;
  public visible: boolean = false;
  displayTexts = [];
  displayValues = [];
  showHide = [];
  showHideValue = [];
  public _divHideShowValues: string;
  public count: number = 0;
  PROPTYPE = {
    DISABLED: 0,
    VISIBILITY: 1,
    STYLE: 2,
    REQUIRED: 3,
    MASTERLIST: 4,
  };
  _idx: any;
  BROKER_DROPDOWNS = {
    Broker_PSEUDOCODE: 0,
    Broker_NAME: 1,
  };

  controlMap = new Map<string, string>();
  stylelMap = new Map<string, string>();
  masterValueMap = new Map<string, DropDownVal[]>();
  selectedValues = new Map<string, DropDownVal[]>();

  defaultSelecText: string = '-- Select --';
  defaultSelectValue: string = '';
  brokerNoCtrl: any;
  _scrollPosition: any;
  constructor(
    private exlService: EXLPdfServiceService,
    public exlHandler: Common
  ) {}

  formatDate(
    value: string | number | Date,
    format: string,
    locale: string,
    timezone?: string
  ): void {}

  ngAfterViewInit(): void {
    this._eachSection.fields.forEach((field) => {
      if (field.type !== 'select') return;
      let masterListValue = this._masterList[field.masterListValue];
      let displayTexts = masterListValue?.text || masterListValue;
      let displayValues = masterListValue?.value || masterListValue;
      if (displayTexts && displayValues) {
        let arr: DropDownVal[] = displayTexts.map((text, index) => ({
          query: text,
          value: displayValues[index],
        }));
        this.addPlaceholdetoArray(field, arr);
        this.masterValueMap.set(field.name, arr);
      }
      if (field.rule) {
        this.applyRule(field, field.values.query);
      }

      if (field.cascadingRule) {
        this.applyCascadingRule(field, field.values.query);
      }
      if (field.values.isSelected) {
        this.selectedValues.set(field.name, field.values.query);
      }
    });
    // if (this._idx != null && this._idx != undefined) {
    //   const element = document.getElementById(this._idx);
    
    //   if (element != null) {
    //     element.scrollIntoView({behavior: "smooth",block:'start'});
    //     element.focus();
    //   }
    // }
   

    

  
    //this.addMasterListtoMap();
  }
  alphaNumberOnly (e) {  // Accept only alpha numerics, not special characters 
    var regex = new RegExp("^[a-zA-Z0-9 ]+$");
    var str = String.fromCharCode(e.keyCode);
    if (regex.test(str)) {
        return true;
    }

    e.preventDefault();
    return false;
  }
  keyPressAlphaNumeric(event) {

    var inp = String.fromCharCode(event.keyCode);

    if (/[a-zA-Z0-9]/.test(inp)) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }
  addMasterListtoMap() {
    this._eachSection.fields.forEach((field) => {
      if (field.type === 'select') {
        let masterListValue = this._masterList[field.masterListValue];
        let displayTexts = masterListValue?.text || masterListValue;
        let displayValues = masterListValue?.value || masterListValue;

        if (displayTexts && displayValues) {
          let arr: DropDownVal[] = displayTexts.map((text, index) => ({
            query: text,
            value: displayValues[index],
          }));

          this.addPlaceholdetoArray(field, arr);
          this.masterValueMap.set(field.name, arr);
        }
      }
    });
  }
  /**
   * Add cascade drop down list to master list
   * @param values
   * @param field
   */
  addToMasterList(field: any, values: string[]) {
    let arr: DropDownVal[] = new Array();
    if (values != undefined) {
      for (let i = 0; i < values.length; i++) {
        let options: DropDownVal = {
          query: values[i],
          value: values[i],
        };
        arr.push(options);
      }
    }
    this.addPlaceholdetoArray(field, arr);
    this.masterValueMap.set(field.name, arr);
  }

  /**
   * This will add placeholder default values to list
   * @param field
   * @param arr
   */
  addPlaceholdetoArray(field: any, arr: DropDownVal[]) {
    if (field.placeholder === undefined || field.placeholder == null) {
      let defaultOpts: DropDownVal = {
        query: this.defaultSelecText,
        value: this.defaultSelectValue,
      };
      arr.unshift(defaultOpts);
    } else {
      let defaultOpts: DropDownVal = {
        query: this.defaultSelecText,
        value: this.defaultSelectValue,
      };
      arr.unshift(defaultOpts);
    }
  }

  showMe(name: string) {
    for (let [key, value] of this.masterValueMap) {
    }
    let val: any = this.exlHandler._dropdownValues[name];
  }
  showhideLabel(showLabel: boolean) {
    if (showLabel != null && showLabel != undefined) {
      return (this.visible = showLabel);
    } else {
      return (this.visible = false);
    }
  }

  setScrollPosition(position: any) {
    var el = document.getElementById('uiScroll');
    el.scrollTop = position;
    console.log('setScrollPosition : ' + position);
  }
  @Input()
  set selectIdx(selectIdx: any) {
    this._idx = selectIdx;
  }
  get selectIdx() {
    return this._idx;
  }
  @Input()
  set iterateTable(message: number) {
    this._iterateTable = message;
  }
  get iterateTable() {
    return this._iterateTable;
  }
  @Input()
  set configData(config: any) {
    this._config = config;
  }
  get configData() {
    return this._config;
  }
  @Input()
  set brokerCascadingList(list: any) {
    this._brokerCascadingList = list;
  }
  get brokerCascadingList() {
    return this._brokerCascadingList;
  }
  @Input()
  set masterList(list: any) {
    this._masterList = list;
  }
  get masterList() {
    return this._masterList;
  }

  @Input()
  set eachSection(eachSection: any) {
    this._eachSection = eachSection;
  }
  get eachSection() {
    return this._eachSection;
  }
  getKeys(obj) {
    return Object.keys(obj);
  }

  /**
   * Handle focus event
   * @param event = _eachSection.field
   * @returns
   */

  onFocus(event: any) {
    
    TableComponent._currentSelectItem = event;
   // this.exlService.clearOldRectangles();
    //if no rows and pageNumber available in selected  field ,Rectangle cannot  be drawn.
    if (event.values == undefined) {
      //  return;
    } else {
      //cordinated are availabe, hence rectangle can be  draw.
      let focusField: Selected = {
        query: event.values.query,
        pageNumber: event.values.pageNumber,
        origin: 'SELECTED',
        selectedCoords: [[]],
        coords: {
          xMin: event.values.xMin == undefined ? null : event.values.xMin,
          yMin: event.values.yMin == undefined ? null : event.values.yMin,
          xMax: event.values.xMax == undefined ? null : event.values.xMax,
          yMax: event.values.yMax == undefined ? null : event.values.yMax,
        },
      };
      if (
        event.values.pageNumber != undefined ||
        event.values.pageNumber != null
      ) {
        this.exlService.clearOldRectangles();
        this.exlService.drawRectangle(focusField);
       
      }
    }
  }

  /*
   Input text box value chnages are saved  to model
  */
  onTextChange(field: any, event: any) {
    
    if (event != null) {
      if(field.values.query==event.target.value){
       // this.onFocus(field);
        return;
      }
    }
    if (field.type === 'text' || field.type === 'number') {
      let selectTextVal: any =event.target.value; //event;//event.target.value;
      if (selectTextVal == '') selectTextVal = undefined;
      let textField: Selected = {
        query: selectTextVal,
      };
      // if (field.type == 'number') {
      //   this.onFocus(field);
      // }
      this.update(textField);
      var fieldValue = this.getFieldValue(field, selectTextVal);
      document.getElementById('lblhidden').innerHTML= field.name;
      Appian.Component.saveValue('onChangeLast', {
        name: field.name,
        fieldDetails: field,
        newValue: fieldValue
      });
    }
  }

  /*
  Date field chanegs are saved to model
  */
  onDateChange(field: any, event: Event) {
    TableComponent._currentSelectItem = field;
    
    if (field.type === 'date') {
      let selecteddate: any = event;
      //if (selecteddate == '') selecteddate = undefined;

      let dateField: Selected = {
        query: selecteddate,
      };
      this.update(dateField);
      const outputdate = selecteddate === '' ? '' : this.convertToDate(selecteddate);

      document.getElementById('lblhidden').innerHTML= field.name;

      var fieldValue = this.getFieldValue(field, outputdate);

      Appian.Component.saveValue('onChangeLast', {
        name: field.name,
        fieldDetails: field,
        newValue: fieldValue,
      });
    }
  }

  public convertToDate(inputString: string): string {
    try {
      let date = new Date(inputString);

      let day = date.getDate().toString().padStart(2, '0');

      let month = date.toLocaleString('default', { month: 'short' });

      let year = date.getFullYear();

      return `${day}/${month}/${year}`;
    } catch (error) {
      console.error(
        'An error occurred while converting the date string:',
        error
      );

      return '';
    }
  }

  /*
     Drop down values are are saved to model
   */
  onSelectChange(field: any, event: Event) {
    TableComponent._currentSelectItem = field;
    let selectedItem: any = event;
    if (field.type === 'select') {
      let selectField: Selected = {
        query: selectedItem,
        pageNumber: field.values.pageNumber,
      };
      this.update(selectField);

      if (field.rule) this.applyRule(field, selectedItem);

      if (field.cascadingRule) {
        this.applyCascadingRule(field, selectedItem);
      }
      document.getElementById('lblhidden').innerHTML= field.name;
      var fieldValue = this.getFieldValue(field, selectedItem);

      Appian.Component.saveValue('onChangeLast', {
        name: field.name,
        fieldDetails: field,
        newValue: fieldValue,
      });
    }
  }

  /**
   * Notify model When appComponent capture PDF changes
   * @param val - Selected values  from PDF ( value and cordinated)
   */
  triggerModelChanegs(val: Selected) {
    this.update(val);
  }

  /*
   Test purpose
   Display selected element
  */
  show() {
    for (let i = 0; i < this._eachSection.fields.length; i++) {
      if (
        this._eachSection.fields[i].name ===
        TableComponent._currentSelectItem.name
      ) {
        alert('Found');
        //   alert(this._eachSection.fields[i].query)
        alert('xMax:' + this._eachSection.fields[i].values.xMax);
        alert('xMix:' + this._eachSection.fields[i].values.xMin);
        alert('page:' + this._eachSection.fields[i].values.pageNumber);
        alert('query:' + this._eachSection.fields[i].values.query);
      }
    }
    const str: string = `Current select Object : 
    ${TableComponent._currentSelectItem.name} :
    ${TableComponent._currentSelectItem.values.query} :
    ${TableComponent._currentSelectItem.values.xMax} :
    ${TableComponent._currentSelectItem.values.xMin} :
    ${TableComponent._currentSelectItem.values.yMax} :
    ${TableComponent._currentSelectItem.values.yMin} :
     `;
    alert(str);
  }

  /*
     update model with the chnages .chanegs will include direct text box entries
     and selected text  values and cordinated  from PDF
  */
  update(val: Selected) {
    if (
      TableComponent._currentSelectItem.type === 'text' ||
      TableComponent._currentSelectItem.type === 'number'
    ) {
      TableComponent._currentSelectItem.query = val.query;

      for (let i = 0; i < this._eachSection.fields.length; i++) {
        if (
          this._eachSection.fields[i].name ===
          TableComponent._currentSelectItem.name
        ) {
          this._eachSection.fields[i].values.query = val.query;
          if (val.query == null || val.query == undefined) {
            this._eachSection.fields[i].values.isSelected = false;
          } else this._eachSection.fields[i].values.isSelected = true;
        }
      }
    }
    if (TableComponent._currentSelectItem.type === 'date') {
      TableComponent._currentSelectItem.query = val.query;
      for (let i = 0; i < this._eachSection.fields.length; i++) {
        if (
          this._eachSection.fields[i].name ===
          TableComponent._currentSelectItem.name
        ) {
          this._eachSection.fields[i].values.query = val.query;
        }
      }
    } else if (TableComponent._currentSelectItem.type === 'select') {
      for (let i = 0; i < this._eachSection.fields.length; i++) {
        if (
          this._eachSection.fields[i].name ===
          TableComponent._currentSelectItem.name
        ) {
          this._eachSection.fields[i].values.query = val.query;

          this._eachSection.fields[i].values.pageNumber = val.pageNumber;
          break;
        }
      }
      TableComponent._currentSelectItem.values.query = val.query;
    }
  }

  /**
   * Bind the Json extracted text box values to model. This is used  to  configure
   * ngModel attribute
   *
   * @param eachField  - Element Field attributes
   * @returns
   */
  bindtoModel(eachField: any) {
    let ret: any = undefined;
    if (eachField.type === 'text') {
      for (let i = 0; i < this._eachSection.fields.length; i++) {
        if (this._eachSection.fields[i].name === eachField.name) {
          ret = this._eachSection.fields[i].values.query;
        }
      }
    } else if (eachField.type === 'date') {
      for (let i = 0; i < this._eachSection.fields.length; i++) {
        if (this._eachSection.fields[i].name === eachField.name) {
          if(this._eachSection.fields[i].values.query!="" && this._eachSection.fields[i].values.query!=null)
          ret = formatDate(
            this._eachSection.fields[i].values.query,
            'yyyy-MM-dd',
            'en-US'
          );

          break;
        }
      }
    } else if (eachField.type === 'number') {
      for (let i = 0; i < this._eachSection.fields.length; i++) {
        if (this._eachSection.fields[i].name === eachField.name) {
          ret = this._eachSection.fields[i].values.query;
          break;
        }
      }
    }
    return ret;
  }

  getFieldValue(field: any, value: any) {
    var fieldValue = {
      field: field.name,
      query: value,
      pageNumber: (field.values.pageNumber =
        field.values.pageNumber === null ? 0 : field.values.pageNumber),
      origin: 'AUTO',
      xMin: (field.values.xMin =
        field.values.xMin === null ? 0 : field.values.xMin),
      xMax: (field.values.xMax =
        field.values.xMax === null ? 0 : field.values.xMax),
      yMin: (field.values.yMin =
        field.values.yMin === null ? 0 : field.values.yMin),
      yMax: (field.values.yMax =
        field.values.yMax === null ? 0 : field.values.yMax),
      type: (field.values.type =
        field.values.type === null ? '' : field.values.type),
      style: (field.values.style =
        field.values.style === null ? '' : field.values.style),
      disabled: (field.values.disabled =
        field.values.disabled === null ? '' : field.values.disabled),
      required: (field.values.required =
        field.values.required === null ? '' : field.values.required),
      accuracy: (field.values.accuracy =
        field.values.accuracy === null ? 0 : field.values.accuracy),
    };

    return fieldValue;
  }

  /**
   * To populate drop downs .Dropdown values are taken from masterValueMap
   * map
   * @param eachField
   * @returns
   */
  getOptions(eachField: any) {
    let values: DropDownVal[] = undefined;
    for (let i = 0; i < this._eachSection.fields.length; i++) {
      if (this._eachSection.fields[i].name === eachField.name) {
        values = this.masterValueMap.get(eachField.name);
        break;
      }
    }
    return values;
  }

  /**
   * Processing rules for each field item.
   *
   * @param field
   */
  applyRule(field: any, selectedValue: string) {
    var count: number = 0;
    if (field.rule) {
      field.rule.forEach((element) => {
        const jsonStr = JSON.stringify(element);
        let obj: Rule = JSON.parse(jsonStr);
        //disable
        if (obj.hasOwnProperty('disabled')) {
          obj.disabled.forEach((n) => {
            this.processRule(n, selectedValue, this.PROPTYPE.DISABLED);
          });
        }

        // //visibility
        // if (obj.hasOwnProperty('visibility')) {
        //   obj.visibility.forEach((n) => {
        //     this.processRule(n, selectedValue, this.PROPTYPE.VISIBILITY);
        //   });
        // }

        // //style
        // if (obj.hasOwnProperty('style')) {
        //   obj.style.forEach((n) => {
        //     this.processStyleRule(n, selectedValue, this.PROPTYPE.STYLE);
        //   });
        // }

        //required
        if (obj.hasOwnProperty('required')) {
          obj.required.forEach((n) => {
            this.processRule(n, selectedValue, this.PROPTYPE.REQUIRED);
          });
        }

        //masterList
        if (obj.hasOwnProperty('masterList')) {
          obj.masterList.forEach((n) => {
            this.processMasterListRule(
              n,
              selectedValue,
              this.PROPTYPE.MASTERLIST
            );
          });
        }
      });
    }
  }

  /**
   * Procese style rules
   * @param obj  - Style rule object
   * @param selectedValue - Selected value  from parent control
   * @param type
   */
  processStyleRule(obj: ruleStyleProps, selectedValue: string, type: number) {
    if (type === this.PROPTYPE.STYLE) {
      obj.controls.forEach((element) => {
        if (obj.values.includes(selectedValue)) {
          this.updateModelwithStyleRules(
            obj.styleProperties,
            element,
            false,
            type
          );
        } else {
          this.updateModelwithStyleRules(
            obj.styleProperties,
            element,
            true,
            type
          );

          if (selectedValue == 'Cover Holder') {
            document.getElementById(element).style.display = 'none';
            this.showHide[element] = false;
          } else {
            document.getElementById(element).style.display = 'block';
            this.showHide[element] = true;
          }
        }
      });
    }
  }

  processMasterListRule(
    obj: masterListProps,
    selectedValue: string,
    type: number
  ) {
    if (type === this.PROPTYPE.MASTERLIST) {
      obj.controls.forEach((element) => {
        if (obj.values.includes(selectedValue)) {
          this.updateModelwithMasterList(obj, element, false, type);
        } else {
          this.updateModelwithMasterList(obj, element, true, type);
        }
      });
    }
  }

  /**
   *
   * @param obj Process disabled and visibility rules
   * @param selectedValue
   * @param type
   */
  processRule(obj: ruleProps, selectedValue: string, type: number) {
    obj.controls.forEach((element) => {
      if (obj.values.includes(selectedValue)) {
        if (type == 0) {
          this.updateModelwithDisableVisibilityRules(
            obj.name,
            element,
            false,
            type
          );
        }
        if (type == 1) {
        }
      } else {
        if (type == 0) {
          this.updateModelwithDisableVisibilityRules(
            obj.name,
            element,
            true,
            type
          );
        }
        if (type == 1) {
          if (selectedValue == 'Cover Holder') {
            document.getElementById(element).style.display = 'block';
            this.showHide[element] = true;
          } else {
            document.getElementById(element).style.display = 'none';
            this.showHide[element] = false;
          }
        }
      }
    });
  }

  /* Update internal model object with the disabled and visibility rule properties
   */

  updateModelwithDisableVisibilityRules(
    val: boolean,
    name: string,
    reset: boolean,
    type: number
  ) {
    for (let i = 0; i < this._eachSection.fields.length; i++) {
      if (this._eachSection.fields[i].name === name) {
        if (type == this.PROPTYPE.DISABLED) {
          if (!reset) {
            this._eachSection.fields[i].disabled = val;
          } else {
            this._eachSection.fields[i].disabled = !val;
          }
        }

        if (type == this.PROPTYPE.VISIBILITY) {
          if (!reset) document.getElementById(name).style.display = 'none';
          else document.getElementById(name).style.display = 'block';
        }

        if (type == this.PROPTYPE.REQUIRED) {
          if (!reset) this._eachSection.fields[i].required = val;
          else
            this._eachSection.fields[i].required =
              !this._eachSection.fields[i].required;
        }
        break;
      }
    }
  }

  /* Update internal model object with the style rule properties
   */
  updateModelwithStyleRules(
    val: string,
    fieldName: string,
    reset: boolean,
    type: number
  ) {
    for (let i = 0; i < this._eachSection.fields.length; i++) {
      if (this._eachSection.fields[i].name === fieldName) {
        if (type == this.PROPTYPE.STYLE) {
          if (!reset) {
            this.stylelMap.set(
              fieldName,
              this._eachSection.fields[i].style.style
            );
            this._eachSection.fields[i].style.style = val;
            this.showHide[fieldName] = true;
            document.getElementById(fieldName).style.display = 'block';
          } else {
            this._eachSection.fields[i].style.style =
              this.stylelMap.get(fieldName);
            this.showHide[fieldName] = false;
            document.getElementById(fieldName).style.display = 'none';
          }
        }
        break;
      }
    }
  }

  /**
   * Update internal model object with the master list rule properties
   */
  updateModelwithMasterList(
    obj: masterListProps,
    fieldName: string,
    reset: boolean,
    type: number
  ) {
    for (let i = 0; i < this._eachSection.fields.length; i++) {
      if (this._eachSection.fields[i].name === fieldName) {
        if (type == this.PROPTYPE.MASTERLIST) {
          if (!reset) {
            this.controlMap.set(
              fieldName,
              this._eachSection.fields[i].masterListValue
            );
            this._eachSection.fields[i].masterListValue = obj.name;
          } else {
            this._eachSection.fields[i].masterListValue =
              this.controlMap.get(fieldName);
          }
        }
        break;
      }
    }
  }

  fieldshowhide(showLabel: boolean) {
    if (showLabel != null && showLabel != undefined) {
      return (this.visible = showLabel);
    } else {
      return (this.visible = false);
    }
  }

  /**
   * Processing cascading rules for each field item.
   *
   * @param field
   */

  applyCascadingRule(field: any, selectedValue: string) {
    if (field.cascadingRule) {
      const brokerDropdowns = this.BROKER_DROPDOWNS;
      const brokerCascadingList = this.brokerCascadingList;
      const masterList = this._masterList;
      const eachSectionFields = this._eachSection.fields;

      for (let element of field.cascadingRule) {
        if (element.filters != undefined && element.filters != null) {
          const { controls, filters } = element;
          const type = filters?.filterColumn === 'brokerPseudoCode' ? 0 : 1;

          if (filters.value.length > 1) {
            for (let z = 0; z < filters.value.length; z++) {
              if (filters.value[z].column == 'brokerCode') {
                this.brokerNoCtrl = filters.value[z].control;
                break;
              }
            }
          }

          if (
            type === brokerDropdowns.Broker_PSEUDOCODE ||
            type === brokerDropdowns.Broker_NAME
          ) {
            const filterKey =
              type === brokerDropdowns.Broker_PSEUDOCODE
                ? 'brokerCode'
                : 'brokerPseudoCode';
            const mapKey =
              type === brokerDropdowns.Broker_PSEUDOCODE
                ? 'brokerPseudoCode'
                : 'brokerName';

            if (filters.value.length > 1 && field.label == 'Broker Pseudo') {
              const findBrokerCtrl = eachSectionFields.find(
                (f) => f.name === this.brokerNoCtrl
              );

              const sortedBrokers = this.brokerCascadingList.filter(
                (broker) =>
                  broker.brokerCode === findBrokerCtrl.values.query &&
                  broker.brokerPseudoCode === selectedValue
              );
              const brokerNameFilter = sortedBrokers.map((e) => e[mapKey]);

              const brokerNamematchingField = eachSectionFields.find(
                (f) => f.name === controls.controlName
              );
              if (brokerNamematchingField) {
                brokerNamematchingField.masterListValue = controls.controlName;
                this.addToMasterList(brokerNamematchingField, brokerNameFilter);
              }
            } else {
              const filteredArray1 = brokerCascadingList.filter(
                (v) => v[filterKey] === selectedValue
              );
              const mappedValues1 = filteredArray1.map((e) => e[mapKey]);

              masterList[controls.controlName] = mappedValues1;
              const matchingField = eachSectionFields.find(
                (f) => f.name === controls.controlName
              );
              if (matchingField) {
                matchingField.masterListValue = controls.controlName;
                this.addToMasterList(matchingField, mappedValues1);
              }
            }

            //Reset Ctrl
            var resetValues: string[];
            const resetField = eachSectionFields.find(
              (r) => r.name === controls.resetControl
            );
            if (resetField) {
              resetField.masterListValue = controls.resetControl;
              this.addToMasterList(resetField, resetValues);
            }
          }
        }
      }
    }
  }

  /**
   * To get validate message
   * @param field
   * @returns
   */

  getValidatedMessage(field: any): string {
    let nRet: string = undefined;
    if (field.type === 'text') {
      for (let i = 0; i < this._eachSection.fields.length; i++) {
        if (this._eachSection.fields[i].name === field.name) {
          nRet = 'Value can not be blank for ' + field.label;
          break;
        }
      }
    }

    if (field.type === 'date') {
      for (let i = 0; i < this._eachSection.fields.length; i++) {
        if (this._eachSection.fields[i].name === field.name) {
          nRet = 'Value can not be blank for ' + field.label;
          break;
        }
      }
    }

    if (field.type === 'select' || field.type == 'searchableDropdown') {
      for (let i = 0; i < this._eachSection.fields.length; i++) {
        if (this._eachSection.fields[i].name === field.name) {
          nRet = 'Select 1 value  for  ' + field.label;
          break;
        }
      }
    }
    return nRet;
  }

  /**
   * Check tooptip should be enabled or disabled.
   * @param field
   * @returns
   */
  showToolTip(field: any): boolean {
    let nRet: boolean = false;
    let fieldName = field.label;
    const fieldsByLabel = this._eachSection.fields.filter(
      (e) => e.label == field.label
    );

    if (fieldsByLabel.length == 1) {
      if (field.values.query == null || field.values.query === undefined) {
        nRet = true;
      }
    }
    //ex:if two or more broker codes are available
    if (fieldsByLabel.length >= 2) {
      for (let j = 0; j < fieldsByLabel.length; j++) {
        if (
          fieldsByLabel[j].values.query == null ||
          fieldsByLabel[j].values.query == undefined
        ) {
          nRet = true;
        }
      }
    }
    return nRet;
  }

  //handle button Event
  handleButtonEvent(field: any, index: number) {
    document.getElementById('lblhidden').innerHTML= field.name;

//     var childElement = document.getElementById(field.name);
// var parentElement = childElement.parentNode;
 
// while (!parentElement && parentElement !== document.body) {
//   parentElement = parentElement.parentNode;
// }

 

//var parentID = parentElement? parentElement.id : null;

    Appian.Component.saveValue('onButtonClick', {
      fieldDetails: field,
      clicked: { field: field.name, query: field.label },
    });
  }
}
