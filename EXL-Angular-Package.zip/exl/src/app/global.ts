
export const DEFAULT_CONFIG = Object.freeze({
    defaultRectanglePadding: 1,
	clearCanvasBeforeHighlighting: true,
	highlightTextOnElementFocus: true,
	highlightAll: true,
	pdfGlobalSearch: true,
	highlightAtPDFScale:true

});