import { TestBed } from '@angular/core/testing';

import { EXLPdfServiceService } from './exlpdf-service-service.service';

describe('EXLPdfServiceServiceService', () => {
  let service: EXLPdfServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EXLPdfServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
