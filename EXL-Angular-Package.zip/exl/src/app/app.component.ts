import { Component, HostListener, ViewChild } from '@angular/core';

import {
  NgxExtendedPdfViewerService,
  FindResultMatchesCount,
} from 'ngx-extended-pdf-viewer';
import JsonData from './case8403.json';
import userJson from './user.json';
import { EXLPdfServiceService } from './exlpdf-service-service.service';
import { Subject } from 'rxjs';
import { SectionComponent } from './section/section.component';
import { Selected } from './coordinate';
import { FieldsComponent } from './fields/fields.component';
import pdfJson from './data.json';
import { ActivatedRoute, Router } from '@angular/router';
declare var Appian: any;
import { ChangeDetectorRef } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'ngx-pdf-viewer';
  public jsonLength: number;
  public jsonData: any = JsonData;
  public formDetails: any;
  public eachMileStone: any;
  public config: any;
  public enableTestMode: boolean;
  public tableData: any = userJson;
  public tabSectionData: any;
  public heightWindow: number;
  public masterValues: any;
  public visible: boolean = false;
  public highlightAll = false;
  public matchCase = false;
  public wholeWord = false;
  public ignoreAccents = false;
  public _searchtext = '';
  currentMatchNumber: number;
  totalMatches: number;
  public selectedIndexTab: number;
  public getScreenWidth: any;
  public getScreenHeight: any;
  public activeTab = 'Case Details';
  activeIndex: number = 0;
  public src: Blob;
  public pdfData: Selected = undefined;
  public isEnableTestMode: boolean = false;
  public TEST_MODE: boolean = true;
  appianDocumentDetails: any;
  public appianDocId: any | undefined;
  public appianEnableTestMode: boolean | undefined;
  public appianConfig: any | undefined;
  public appianMasterValues: any | undefined;
  public appianFormDetails: any | undefined;
  public appianCascadingValues: any | undefined;
  public appianConnectedSystem: any | undefined;
  public docData: any | undefined;
  public docName: string | undefined;
  public _PDFtext: string;
  public brokerCascadingValues: any;
  public count: number = 0;
  mySubscription;
  public clickbutton: boolean = false;
  _scrollPosition: any;
  public appianScrolltoField: any | undefined;
  ngOnInit() {
    if (this.TEST_MODE) {
      this.setStaticData(this.activeTab, this.activeIndex);
    }
    Appian.Component.onNewValue((newValues: any) => {
      this.count++;
      // console.log('onNewValue :' + this.count);

      try {
        if (newValues.enableTestMode != null) {
          this.appianEnableTestMode = newValues.enableTestMode;
          // console.log('enableTestMode :' + this.appianEnableTestMode);
        }

        if (newValues.enableTestMode) {
          this.changeActiveTab(this.activeTab, 0);
          this.formDetails =
            this.jsonData[this.jsonLength - 1].formDetails.milestones;
          this.eachMileStone =
            this.jsonData[this.jsonLength - 1].formDetails.milestones;
          this._PDFtext = pdfJson[0].pdfFile;
          this.service.setPDFContents(this._PDFtext);
        } else {
          if (this.count <= 1) {
            if (newValues.appianDocId != null) {
              this.appianDocId = newValues.appianDocId;
            }

            const payload = {
              documentId: newValues.appianDocId,
            };
            if (newValues.docAccessConnectedSystem != null) {
              this.appianConnectedSystem = newValues.docAccessConnectedSystem;

              const promise = Appian.Component.invokeClientApi(
                this.appianConnectedSystem,
                'DocumentRetrieveClientApi',
                payload
              ).then(this.handleClientApiResponse, this.handleError);
            }
          }
          if (newValues.formDetails != null) {
            this.appianFormDetails = newValues.formDetails;
            this.formDetails = newValues.formDetails.milestones;
            this.tabSectionData = newValues.formDetails.milestones;
            // console.log('formDetails :' + this.appianFormDetails);
          }
          if (newValues.appianScrolltoPosition != null) {
            this.appianScrolltoField = newValues.appianScrolltoPosition;
          }
          //appianScrolltoPosition
          if (newValues.masterValues != null) {
            this.appianMasterValues = newValues.masterValues;
            this.masterValues = newValues.masterValues;
            //console.log('masterValues :' + this.appianMasterValues);
          }
          if (newValues.brokerCascadingList != null) {
            this.appianCascadingValues = newValues.brokerCascadingList;
            this.brokerCascadingValues = newValues.brokerCascadingList;
            // console.log('appianCascadingValues :' + this.appianCascadingValues);
          }

          if (newValues.config != null) {
            this.appianConfig = newValues.config;
            // console.log('config :' + this.appianConfig);
          }
        }
        if (this.appianEnableTestMode) {
          // console.log('Plugin running in  Test mode');
          this.setStaticData(this.activeTab, 0);
        } else {
          // console.log('Plugin running in  Production mode');

          this.setDynamicData(this.activeIndex);

          // if (this.count != 1) {
          this.refresh();

          // }
        }
      } catch (e) {
        console.error(e);
      }
    });
    // const scrollDemo = document.querySelector('#uiScroll');
    // scrollDemo.addEventListener(
    //   'scroll',
    //   (event) => {
    //      console.log('scrollTop: ' + scrollDemo.scrollTop);
    //     this._scrollPosition = scrollDemo.scrollTop;
    //   },
    //   { passive: true }
    // );
  }
  // setScrollPosition(position: any) {
  //   var el = document.getElementById('uiScroll');
  //   el.scrollTop = position;
  //   console.log('setScrollPosition : ' + position);
  // }
  refresh(): void {
    //  this.cdr.detectChanges();
    document.getElementById(this.activeTab).click();
  }
  handleClientApiResponse = (response: any) => {
    // console.log('handleClientApiResponse :' + response);

    let payload = {};
    if (
      response.type === 'INVOCATION_SUCCESS' &&
      response.payload !== undefined &&
      response.payload.hasOwnProperty('error')
    ) {
      Appian.Component.setValidations([
        'Error occured while retrieving the document, Please check if you have sufficient privileges to view it. ' +
          JSON.stringify(response.payload),
      ]);
    }

    if (
      response.type === 'INVOCATION_SUCCESS' &&
      response.payload !== undefined &&
      response.payload.hasOwnProperty('docData')
    ) {
      payload = response.payload;

      this._PDFtext = response.payload.docData;
    } else {
      Appian.Component.setValidations([
        'Unable to retrieve document from Appian, please check documentId',
        response.payload.error,
      ]);
    }

    return;
  };

  handleError(handleResponse: any) {
    //console.log('handleError :' + handleResponse);
    if (handleResponse.error && handleResponse.error[0]) {
      Appian.Component.setValidations([handleResponse.error]);
    } else {
      Appian.Component.setValidations(['An unspecified error occurred']);
    }
    return;
  }

  @HostListener('window:resize', ['$event'])
  onWindowResize() {
    this.getScreenWidth = window.innerWidth;
    this.getScreenHeight = window.innerHeight;
  }
  // @HostListener('window:scroll', ['$event'])
  // scrollHandler(event) {
  //   const scrollDemo = document.querySelector('#uiScroll');
  //   scrollDemo.addEventListener(
  //     'scroll',
  //     (event) => {
  //       //console.log('scrollTop: ' + scrollDemo.scrollTop);
  //       this._scrollPosition = scrollDemo.scrollTop;
  //     },
  //     { passive: true }
  //   );

  //   Appian.Component.saveValue('onScrollPosition', this._scrollPosition);
  // }
  public changeActiveTab(activeTab: string, index: number) {
    // console.log('activeTab :' + activeTab);
    this.activeIndex = index;
    if (this.appianEnableTestMode) {
      this.setStaticData(activeTab, index);
      this.showhideUtility(this.eachMileStone.fields);
    } else {
      this.activeTab = activeTab;
      this.selectedIndexTab = index;
      this.tabSectionData = this.formDetails[index].sections;
      this.eachMileStone = this.formDetails[index];
      this.showhideUtility(this.eachMileStone.fields);
    }
    Appian.Component.saveValue('onTabChange', { selectedTab: activeTab });

    //console.log(`MileStone Data for  index ${index}   : ${this.eachMileStone}`);
  }

  public updateFindMatchesCount(result: FindResultMatchesCount) {
    
    this.currentMatchNumber = result.current;
    this.totalMatches = result.total;
  }

  onEvent(pageChange: string, $event: any) {
    // console.log('Page Changes detected');
  }

  showhideUtility(fieldsCheck: any) {
    if (fieldsCheck != null && fieldsCheck != undefined) {
      this.visible = fieldsCheck.length > 0 ? true : false;
    } else {
      this.visible = false;
    }
  }

  constructor(
    private ngxExtendedPdfViewerService: NgxExtendedPdfViewerService,
    public service: EXLPdfServiceService,
    private route: ActivatedRoute,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {
    this.src = this.service.src;
  }

  showSelectedText() {
    if (window.getSelection) {
      if (window.getSelection().toString().length > 0) {
        const rect = this.service.getHightlightedCoords();
        const str = `xMin :${rect.coords.xMin} ,xMax :${rect.coords.xMax},
        yMin ${rect.coords.yMin} , yMax ${rect.coords.yMax} `;
        //  alert(str)
        this.pdfData = {
          query: window.getSelection().toString(),
          coords: {
            xMax: rect.coords.xMax,
            xMin: rect.coords.xMin,
            yMax: rect.coords.yMax,
            yMin: rect.coords.yMin,
          },
          pageNumber: rect.pageNumber,
        };
        this.notifyChild();
      }
    }
  }

  childNotifier: Subject<Selected> = new Subject<Selected>();

  childNotifierSection: Subject<Selected> = new Subject<Selected>();

  notifyChild() {
    this.childNotifier.next(this.pdfData);
    this.childNotifierSection.next(this.pdfData);
    this.sectionComponent.triggerSectionUpdates();
    this.fieldComponent?.triggerModelChanegs();
  }

  @ViewChild(SectionComponent) sectionComponent: {
    triggerSectionUpdates: () => void;
  };
  @ViewChild(FieldsComponent) fieldComponent: {
    triggerModelChanegs: () => void;
  };

  /**
   * Load test data
   * */
  setStaticData(activeTab: string, index: number) {
    //console.log('Loading Static Data from Json file ');
    this.activeTab = activeTab;
    this.jsonLength = JsonData.length;
    this.jsonData = JsonData;
    this.formDetails =
      this.jsonData[this.jsonLength - 1].formDetails.milestones;
    this.tabSectionData =
      this.jsonData[this.jsonLength - 1].formDetails.milestones[index].sections;
    this.eachMileStone =
      this.jsonData[this.jsonLength - 1].formDetails.milestones;
    this.config = this.jsonData[this.jsonLength - 1].config;
    this.masterValues = this.jsonData[this.jsonLength - 1].masterValues;
    this.brokerCascadingValues =
      this.jsonData[this.jsonLength - 1].brokerCascadingList;
    this._PDFtext = pdfJson[0].pdfFile;
    this.service.setPDFContents(this._PDFtext);

    // console.log('MileStone Data : ' + JSON.stringify(this.eachMileStone));
  }

  /**
   * Load dynamic data from Appian
   */
  setDynamicData(index: number) {
    // console.log('Loading Dynamic Data from Appian ');

    this.formDetails = this.appianFormDetails.milestones;
    this.eachMileStone = this.appianFormDetails.milestones;
    this.masterValues = this.appianMasterValues;
    this.tabSectionData = this.appianFormDetails.milestones[index].sections;
    this.brokerCascadingValues = this.appianCascadingValues;
    this.config = this.appianConfig;
    this.activeTab = this.formDetails[index].label;
    //document.getElementById(this.activeTab).click();
    //console.log('MileStone Data : ' + JSON.stringify(this.eachMileStone));
  }
}
