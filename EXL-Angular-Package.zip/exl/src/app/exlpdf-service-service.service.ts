import { Injectable } from '@angular/core';

import {
  NgxExtendedPdfViewerService,
  IPDFViewerApplication,
  PageViewport,
} from 'ngx-extended-pdf-viewer';

@Injectable({
  providedIn: 'root',
})
export class EXLPdfServiceService {
  public highlightAll = false;
  public matchCase = false;
  public wholeWord = false;
  public ignoreAccents = false;
  public _searchtext = 'USD';
  public src: Blob;
  pageElement: HTMLElement;

  constructor(
    private ngxExtendedPdfViewerService: NgxExtendedPdfViewerService
  ) {}

  /**
   * This method sets the PDF contents by converting a base64 encoded string
   * to a Blob object, which can be used to display the PDF in a viewer.
   *
   * @param pdfContents The base64 encoded representation of the PDF data.
   */
  setPDFContents(pdfContents: string | null | undefined): void {
    if (!pdfContents) {
      console.error('Error: pdfContents cannot be null or undefined');
      return;
    }

    try {
      // Convert base64 encoded string to a binary string
      const byteCharacters = atob(pdfContents);

      // Create a Uint8Array directly from the binary string using Uint8Array.from and String.prototype.charCodeAt
      const byteArray = Uint8Array.from(
        { length: byteCharacters.length },
        (_, i) => byteCharacters.charCodeAt(i)
      );

      // Create a Blob object with the byteArray.
      // This Blob object can be used to display the PDF content in a viewer by setting it as the source.
      this.src = new Blob([byteArray], { type: 'application/pdf' });
    } catch (error) {
      // Logging the error to help with debugging.
      // It might be beneficial to extend the error handling here, possibly with a user notification.
      console.error('Error converting base64 to Blob:', error);
    }
  }

  /**
   * This method is used to highlight a specific section in the PDF viewer application.
   * It checks if a specific scale is defined for highlighting and sets it, and then
   * draws a rectangle around the selected section. If the selected page is different
   * from the current page, it switches to the selected page before drawing the rectangle.
   *
   * @param {Selected} selected - The selected object containing details of the section to be highlighted.
   */
  showHighlight(selected: Selected) {
    // Obtain a reference to the PDFViewerApplication object from the window object
    const PDFViewerApplication: IPDFViewerApplication = (window as any)
      .PDFViewerApplication;

    // Store a reference to the pdfViewer for easier access and to prevent repeated property lookups
    const pdfViewer = PDFViewerApplication.pdfViewer;

    // Check if the highlightAtPDFScale property is not null or undefined before attempting to set the scale
    if (DEFAULT_CONFIG.highlightAtPDFScale != null) {
      // Uncomment and complete the following line to set the scale based on the highlightAtPDFScale configuration
      // pdfViewer._setScale(DEFAULT_CONFIG.highlightAtPDFScale);
    }

    // If the selected page number is different from the current page number, change the page and then draw the rectangle
    if (selected.pageNumber !== pdfViewer.currentPageNumber) {
      pdfViewer.currentPageNumber = selected.pageNumber;

      // Use an arrow function to maintain the correct context (`this`) inside the timeout callback
      setTimeout(() => {
        this.drawRectangle(selected);
      }, 50);
    } else {
      // If the page number is the same, directly draw the rectangle without changing the page
      
      this.drawRectangle(selected);
    }
  }

  /**
   * Draws a rectangle in the PDF based on the input coordinates within the 'selected' parameter.
   *
   * @param selected - An object containing the necessary data to draw a rectangle on the PDF, including coordinates and page number.
   */
  drawRectangle(selected: Selected): void {
    // Log the coordinates of the rectangle to be drawn
    //console.log('drawRectangle:');
    
    let pageElement: any;
    const {
      coords: { xMax, xMin, yMax, yMin },
      pageNumber,
    } = selected;
    //console.log(`Rectangle Coordinates : ${xMax} : ${xMin} : ${yMax} : ${yMin}`);

    // Get the PDFViewerApplication object and set the current page number
    const PDFViewerApplication: IPDFViewerApplication = (window as any)
      .PDFViewerApplication;
    if (pageNumber > 0) {
      PDFViewerApplication.pdfViewer.currentPageNumber = pageNumber;

      // Get the page view and the viewport for the current page
      const page = PDFViewerApplication.pdfViewer.getPageView(
        PDFViewerApplication.pdfViewer.currentPageNumber - 1
      );
      
      if (page.canvas != undefined ) {
         pageElement = page.canvas.parentElement;

        const viewport = page.viewport;

        // Convert the selected coordinates to a format suitable for drawing on the PDF
        selected.selectedCoords = this.convertPercentageToPixels(
          this.convertRectangleCoordsToNativeCoords(
            this.convertToPercentageAndAddMargin(selected, viewport)
          ),
          pageNumber
        );

        // Scroll the view to the page containing the rectangle to be drawn, centering the page in the view
        // this.ngxExtendedPdfViewerService.scrollPageIntoView(pageNumber, {
        //   top: '50%',
        // });

        // Loop through each set of coordinates in selectedCoords and draw a rectangle on the PDF for each
        
        selected.selectedCoords.forEach((rect) => {
          // Convert the rectangle coordinates to viewport coordinates
          const bounds = viewport.convertToViewportRectangle(rect);

          // Create a new div element to represent the rectangle
          const el = document.createElement('div');

          try {
            el.className = 'custom-annotations';
            el.style.position = 'absolute';
            el.style.border = '0.3em solid';
            el.style.opacity = '0.7';
            el.style.left = `${Math.min(bounds[0], bounds[2]) - 8}px`;
            el.style.top = `${Math.min(bounds[1], bounds[3]) - 16}px`;
            el.style.width = `${Math.abs(bounds[0] - bounds[2])+10}px`;
            el.style.height = `${Math.abs(bounds[1] - bounds[3]) + 32}px`;
          } catch (e) {
            console.error(e);
            el.setAttribute(
              'style',
              `position: absolute; background-color: blue; opacity: 0.4; left: ${Math.min(
                bounds[0],
                bounds[2]
              )}px; top: ${Math.min(bounds[1], bounds[3])}px; width: ${Math.abs(
                bounds[0] - bounds[2]
              )}px; height: ${Math.abs(bounds[1] - bounds[3])}px;`
            );
          }

          const a: any = `${Math.min(bounds[1], bounds[3]) - 5}`;
          const result = Math.round((a / 1000) * 100);

          // Scroll the view to the page containing the rectangle to be drawn, centering the page in the view
          if (result != null && result != undefined) {
            this.ngxExtendedPdfViewerService.scrollPageIntoView(pageNumber, {
              top: result + '%',
            });
          } else {
            this.ngxExtendedPdfViewerService.scrollPageIntoView(pageNumber, {
              top: '50%',
            });
          }

          // Append the rectangle element to the page element

          pageElement.appendChild(el);
        });
      }else{
        setTimeout(() => {
          this.drawRectangle(selected);
        }, 50);
      }
      
    }
  }

  /**
   * Converts rectangle coordinates from a Coords object to a 2D array format.
   *
   * @param coords - An object containing the properties xMin, yMin, xMax, and yMax, which represent the coordinates of a rectangle.
   * @returns A 2D array containing a single array with the format: [[xMin, yMin, xMax, yMax]].
   */
  private convertRectangleCoordsToNativeCoords(coords: Coords): number[][] {
    return [[coords.xMin, coords.yMin, coords.xMax, coords.yMax]];
  }

  /**
   * Converts the coordinates of a selected area to percentages and adds margins to prevent rectangle boundaries from overlapping with the text.
   *
   * @param selected - An object containing information about the selected area, including its coordinates.
   * @param viewPort - An optional parameter representing the viewport of the PDF viewer.
   * @returns A Coords object with updated coordinates considering the percentage conversion and added margins.
   */
  private convertToPercentageAndAddMargin(
    selected: Selected,
    viewPort?: any
  ): Coords {
    let coords = selected.coords;

    // Convert coordinates values from pixels to percentage to facilitate margin adjustments
    coords.xMin = this.convertValueInPercentage(coords.xMin);
    coords.yMin = this.convertValueInPercentage(coords.yMin);
    coords.xMax = this.convertValueInPercentage(coords.xMax);
    coords.yMax = this.convertValueInPercentage(coords.yMax);

    // Initialize padding values to zero
    let paddingX = 0;
    let paddingY = 0;

    // If default padding configuration is available and greater than zero, assign it to padding variables
    if (
      DEFAULT_CONFIG.hasOwnProperty('defaultRectanglePadding') &&
      DEFAULT_CONFIG.defaultRectanglePadding > 0
    ) {
      paddingX = DEFAULT_CONFIG.defaultRectanglePadding;
      paddingY =
        selected.origin === 'SELECTED'
          ? 0
          : DEFAULT_CONFIG.defaultRectanglePadding;
    }

    // Adjust coordinates by applying padding to prevent overlapping with text
    return {
      xMin: coords.xMin - paddingX,
      yMin: this.invertYAxis(coords.yMin) + paddingY,
      xMax: coords.xMax + paddingX,
      yMax: this.invertYAxis(coords.yMax) - paddingY,
    };
  }

  /**
   * Scales the coordinates of a selected area to fit the viewport by performing several operations:
   * 1. Reducing the coordinates values to tens.
   * 2. Inverting the y-axis coordinates.
   * 3. Converting the coordinates values to decimals.
   *
   * These transformations are applied to adapt the coordinates to a different scale or coordinate system.
   *
   * @param selected - An object containing the coordinates of the selected area.
   * @param viewport - An optional parameter representing the viewport of the PDF viewer (not used in the current implementation).
   * @param page - An optional parameter representing the page of the PDF viewer (not used in the current implementation).
   * @param pageIndex - An optional parameter representing the index of the page in the PDF viewer (not used in the current implementation).
   *
   * @returns A Coords object with updated coordinates considering the scaling and transformations applied.
   */
  private scaleCoordinatesToViewport(
    selected: Coords,
    viewport?: any,
    page?: any,
    pageIndex?: any
  ): Coords {
    // Applying a series of transformations to the x and y coordinates of the selected area.
    // The transformations include reducing to tens, inverting the y-axis, and converting to decimals.
    const transformCoord = (coord: number, invertY: boolean = false) => {
      let transformedCoord = this.reduceToTens(coord);
      if (invertY) {
        transformedCoord = this.invertYAxis(transformedCoord);
      }
      return this.convertToDecimals(transformedCoord);
    };

    return {
      xMin: transformCoord(selected.xMin),
      yMin: transformCoord(selected.yMin, true),
      xMax: transformCoord(selected.xMax),
      yMax: transformCoord(selected.yMax, true),
    };
  }

  /**
   * Converts a given value to a decimal number with a single decimal place precision,
   * and then divides it by 100 to get a percentage representation.
   *
   * @param val - The input number that needs to be converted to a decimal percentage.
   *
   * @returns The converted decimal value as a percentage.
   */
  private convertToDecimals(val: number): number {
    return this.round(val, 1) / 100;
  }

  /**
   * Converts a given value to a percentage representation by multiplying it by 100.
   * This is useful in scenarios where the input value is in a range of 0-1 and
   * needs to be scaled to a percentage representation.
   *
   * @param val - The input number that needs to be converted to a percentage.
   *
   * @returns The converted value in percentage.
   */
  private convertValueInPercentage(val: number): number {
    return val * 100;
  }

  /**
   * Rounds a given value to a specified number of decimal places. The rounding is
   * performed by multiplying the input value with a multiplier (calculated based on
   * the required precision), rounding it to the nearest integer, and then dividing
   * it by the multiplier to get the rounded value.
   *
   * @param value - The input number that needs to be rounded.
   * @param precision - The number of decimal places to which the input number needs to be rounded.
   *
   * @returns The input value rounded to the specified number of decimal places.
   */
  private round(value: number, precision: number): number {
    const multiplier = Math.pow(10, precision || 0);
    return Math.round(value * multiplier) / multiplier;
  }

  /**
   * Converts a 2D array representing pixel coordinates to percentages based on the viewport's dimensions.
   * This is done to help in positioning elements like annotations correctly even when the PDF's scale changes.
   *
   * @param selected - A 2D array where each sub-array contains 4 numbers representing pixel coordinates ([x1, y1, x2, y2]).
   * @param pageNumber - The page number where these coordinates are being used, to get the appropriate viewport dimensions.
   *
   * @returns A 2D array with the same structure as the input, but with the coordinates converted to percentages.
   */
  private convertPixelToPercentage(
    selected: number[][],
    pageNumber: number
  ): number[][] {
    // Get the viewport for the given page number to access its dimensions for the conversion
    const viewPort = this.getPdfViewPort(pageNumber);

    // The dimensions of the viewport, used to convert pixels to percentages
    const width = parseFloat(viewPort.viewBox[2].toString());
    const height = parseFloat(viewPort.viewBox[3].toString());

    // Using map function to iterate over each element in the selected array and convert each coordinate value to percentage
    return selected.map((coords) =>
      coords.map(
        (value, index) =>
          (parseFloat(value.toString()) / (index % 2 === 0 ? width : height)) *
          100
      )
    );
  }

  /**
   * Adjusts the coordinates in the selected array by adding buffer values in pixels.
   * This helps in ensuring that the elements (like rectangles) created using these coordinates
   * have proper spacing/margin around them.
   *
   * @param selected - A 2D array where each sub-array contains 4 numbers representing coordinates ([x1, y1, x2, y2]).
   * @param xMinBuffer - The buffer to be added to the minimum x coordinate values (x1).
   * @param yMinBuffer - The buffer to be added to the minimum y coordinate values (y1).
   * @param xMaxBuffer - The buffer to be added to the maximum x coordinate values (x2).
   * @param yMaxBuffer - The buffer to be added to the maximum y coordinate values (y2).
   *
   * @returns A 2D array with the same structure as the input, but with adjusted coordinates with added buffer values.
   */
  private addBufferInPixels(
    selected: number[][],
    xMinBuffer: number,
    yMinBuffer: number,
    xMaxBuffer: number,
    yMaxBuffer: number
  ): number[][] {
    return selected.map((coords) => [
      coords[0] > xMinBuffer ? coords[0] - xMinBuffer : coords[0],
      coords[1] > yMinBuffer ? coords[1] - yMinBuffer : coords[1],
      coords[2] > xMaxBuffer ? coords[2] + xMaxBuffer : coords[2],
      coords[3] > yMaxBuffer ? coords[3] + yMaxBuffer : coords[3],
    ]);
  }

  /**
   * Adjusts the coordinates in the coords array according to the scale factor provided by the viewPort.
   * This ensures that the coordinates are in sync with the current viewPort scale.
   *
   * @param viewPort - An object that contains properties including the current scale of the viewPort.
   * @param coords - A 2D array where each sub-array contains 4 numbers representing coordinates ([x1, y1, x2, y2]).
   *
   * @returns A 2D array with the same structure as the input, but with coordinates adjusted to the viewPort scale.
   */
  private updateCoordsToViewPortScale(
    viewPort: PageViewport,
    coords: number[][]
  ): number[][] {
    // console.log(viewPort, JSON.stringify(coords));

    // Using the map function to create a new array with coordinates scaled according to the viewPort scale.
    const updatedCoords = coords.map((coordSet) =>
      coordSet.map((coord) => coord * viewPort.scale)
    );

    //console.log(JSON.stringify(updatedCoords));
    return updatedCoords;
  }

  /**
   * Inverts the value on the Y-axis. Given a value, it returns the difference between 100 and the given value.
   * This is used to adapt coordinates when there is a change or inversion in the Y-axis orientation.
   *
   * @param val - The value on the Y-axis that needs to be inverted.
   *
   * @returns The inverted value on the Y-axis.
   */
  private invertYAxis(val: number): number {
    return 100 - val;
  }

  /**
   * This method takes an array of rectangle coordinates and calculates the
   * minimum and maximum values for x and y coordinates across all rectangles,
   * effectively finding the bounding box that contains all rectangles.
   *
   * @param selected - A 2D array where each sub-array contains coordinates of a rectangle ([x1, y1, x2, y2]).
   *
   * @returns An object with properties representing the minimum and maximum x and y values across all rectangles.
   */
  private getRectangleCoords(selected: number[][]): Coords {
    // Initializing the result with the first coordinate set
    let result = selected.reduce(
      (acc, current) => {
        return {
          xMin: Math.min(acc.xMin, current[0]),
          yMin: Math.min(acc.yMin, current[1]),
          xMax: Math.max(acc.xMax, current[2]),
          yMax: Math.max(acc.yMax, current[3]),
        };
      },
      {
        xMin: selected[0][0],
        yMin: selected[0][1],
        xMax: selected[0][2],
        yMax: selected[0][3],
      }
    );

    return result;
  }

  /**
   * Generates a random color with a modified luminance value.
   * The generated color is then made darker using the colorLuminance method.
   *
   * @returns A string representing a color in hex format.
   */
  private getRandomColor(): string {
    // Generating a random color in hex format and modifying its luminance to make it darker.
    return this.colorLuminance(
      Math.floor(Math.random() * 16777215).toString(16),
      -0.7
    );
  }

  /**
   * This method adjusts the luminance of a hex color.
   *
   * @param hex - A string representing a hex color code.
   *              It can be in 3-digit shorthand or 6-digit full format.
   * @param lum - A number representing the amount to adjust the luminance of the color.
   *              Positive values will lighten the color and negative values will darken it.
   *              It should be in the range of [-1, 1] where -1 is completely dark and 1 is completely light.
   *              The default value is 0 which means no change in luminance.
   *
   * @returns A string representing the hex color code with adjusted luminance.
   *
   * Usage:
   * colorLuminance("#ff5733", -0.5); // returns a darker color
   * colorLuminance("#ff5733", 0.5); // returns a lighter color
   */
  private colorLuminance(hex: string, lum: number): string {
    // Replace any characters that are not valid hex characters with an empty string
    hex = String(hex).replace(/[^0-9a-f]/gi, '');

    // If hex length is less than 6, duplicate each character to form a valid hex color code
    if (hex.length < 6) {
      hex = `${hex[0]}${hex[0]}${hex[1]}${hex[1]}${hex[2]}${hex[2]}`;
    }

    // Set lum to 0 if it is not provided
    lum = lum || 0;

    // Initialize a variable to hold the resultant color code
    var rgb = '#';

    // Loop through each pair of hex characters, convert to decimal, adjust luminance and convert back to hex
    for (let i = 0; i < 3; i++) {
      // Convert hex pair to decimal
      let c = parseInt(hex.substring(i * 2, i * 2 + 2), 16);

      // Adjust the luminance of the color component and clamp it between 0 and 255
      let color = Math.round(Math.min(Math.max(0, c + c * lum), 255)).toString(
        16
      );

      // Add the adjusted color component to the result, ensuring it's two characters long
      rgb += ('00' + color).substring(color.length);
    }

    // Return the resulting color code
    return rgb;
  }

  /**
   * This method retrieves the viewport of a specific page in a PDF document.
   *
   * @param pageNumber - The number of the page for which the viewport needs to be retrieved.
   *                     If not specified, it defaults to the current page number.
   * @returns {PageViewport} - The viewport details of the specified or current page.
   */
  private getPdfViewPort(pageNumber: number): PageViewport {
    // Getting the PDFViewerApplication instance from the global window object

    const PDFViewerApplication: IPDFViewerApplication = (window as any)
      .PDFViewerApplication;

    // If pageNumber is not provided, default to the current page number
    if (pageNumber === undefined || pageNumber === null || pageNumber === 0) {
      pageNumber = PDFViewerApplication.pdfViewer.currentPageNumber;
    }

    // Getting the page view and the parent element of the page's canvas
    const page = PDFViewerApplication.pdfViewer.getPageView(pageNumber - 1);
    const pageElement = page.canvas.parentElement;

    // Getting the viewport of the second page (index 1)
    const pageviewPort = PDFViewerApplication.pdfViewer.getPageView(1).viewport;

    // Returning the viewport of the requested page
    return pageviewPort;
  }

  /**
   * Converts coordinates from percentage to pixels based on the page's view port dimensions.
   *
   * @param coords - An array of coordinate arrays, where each coordinate array contains
   *                 four elements representing a bounding box ([xMin, yMin, xMax, yMax]).
   * @param pageNumber - The number of the page for which the conversion is to be done.
   * @returns - An array of coordinate arrays converted to pixel values.
   */
  private convertPercentageToPixels(
    coords: number[][],
    pageNumber: number
  ): number[][] {
    // Get the viewport for the specified page number
    var viewPort = this.getPdfViewPort(pageNumber);

    // Convert each coordinate from percentage to pixels based on the viewport dimensions
    for (let coord of coords) {
      coord[0] = (viewPort.viewBox[2] / 100) * this.reduceToTens(coord[0]);
      coord[2] = (viewPort.viewBox[2] / 100) * this.reduceToTens(coord[2]);
      coord[1] = (viewPort.viewBox[3] / 100) * this.reduceToTens(coord[1]);
      coord[3] = (viewPort.viewBox[3] / 100) * this.reduceToTens(coord[3]);
    }

    return coords;
  }

  /**
   * Reduces the input value by tens until it is less than 100 using recursion.
   *
   * @param val - The input number that needs to be reduced.
   * @returns - The reduced value.
   */
  private reduceToTens(val: number): number {
    // Base case: if the value is less than 100, return the value
    if (val < 100) return val;

    // Recursive case: reduce the value by 100 and call the function again
    return this.reduceToTens(val - 100);
  }

  /**
   * Removes all elements with the class name 'custom-annotations' from the document.
   */
  clearOldRectangles(): void {
    // Get a collection of elements with the class name 'custom-annotations'
    //console.log('clearOldRectangles:');
    const canvases = document.querySelectorAll('.custom-annotations');

    // Loop through each element in the collection and remove it from the DOM
    canvases.forEach((canvas) => canvas.remove());
  }

  /**
   * Extracts the coordinates of the selected text from the PDF and
   * scales them according to the viewport, and adds a buffer to the pixels.
   *
   * @returns An object containing the page number and scaled coordinates
   */
  getHightlightedCoords() {
    // Initializing PDFViewerApplication and getting the current page details
    const PDFViewerApplication: IPDFViewerApplication = (window as any)
      .PDFViewerApplication;
    const pageIndex = PDFViewerApplication.pdfViewer.currentPageNumber;
    const page = PDFViewerApplication.pdfViewer.getPageView(pageIndex);
    const pageRect = page.canvas.getClientRects()[0];
    const viewport = page.viewport;

    // Retrieving current selection details
    const sel: Selection = window.getSelection();
    //console.log('window.getSelection() :' + sel);
    const selectionRects = sel.getRangeAt(0).getClientRects();
    const selectionRectsList = Array.from(selectionRects);

    // Mapping the selection rectangles to their respective coordinates in the PDF
    const selected = selectionRectsList.map((r) => {
      const x = viewport.convertToPdfPoint(
        r.left - pageRect.left,
        r.top - pageRect.top
      ) as number[];
      const y = viewport.convertToPdfPoint(
        r.right - pageRect.left,
        r.bottom - pageRect.top
      ) as number[];
      return x.concat(y);
    });

    // Scaling coordinates to viewport and adding buffer pixels
    return {
      pageNumber: pageIndex,
      coords: this.scaleCoordinatesToViewport(
        this.getRectangleCoords(
          this.convertPixelToPercentage(
            this.addBufferInPixels(selected, 15, 15, 15, 15),
            pageIndex
          )
        ),
        viewport,
        page,
        pageIndex
      ),
    };
  }

  /**
   * Highlights the specified text within the PDF viewer.
   *
   * @param text - The text to highlight.
   */
  hightlight(text: string) {
    //console.log('Search Text :' + text);

    // Using the PDF viewer service to find and highlight the specified text
    // based on the search criteria provided by the various flags such as
    // 'highlightAll', 'matchCase', and 'wholeWords'.
    if (
      this.ngxExtendedPdfViewerService.find(text, {
        highlightAll: this.highlightAll,
        matchCase: this.matchCase,
        wholeWords: this.wholeWord,
        //  ignoreAccents: this.ignoreAccents
      })
    ) {
      // Updating the search text attribute to the text that was found and highlighted.
      this._searchtext = text;
    }
  }
}

// A constant object holding the default configuration settings.
// Object.freeze is used to make the object immutable, preventing any changes to it.
const DEFAULT_CONFIG = Object.freeze({
  defaultRectanglePadding: 1, // Default padding around rectangles
  clearCanvasBeforeHighlighting: true, // Flag to clear canvas before highlighting new text
  highlightTextOnElementFocus: true, // Flag to highlight text when the element gains focus
  highlightAll: true, // Flag to indicate if all occurrences should be highlighted
  pdfGlobalSearch: true, // Flag to enable global search in the PDF
  highlightAtPDFScale: true, // Flag to enable highlighting at the PDF's scale
});

// Class representing coordinates with properties to store the minimum and maximum values for X and Y axis.
class Coords {
  xMin: number; // Minimum value on the X-axis
  xMax: number; // Maximum value on the X-axis
  yMin: number; // Minimum value on the Y-axis
  yMax: number; // Maximum value on the Y-axis
}

// Class representing selected text with properties to store details like page number, coordinates, and query text.
class Selected {
  origin?: string; // The origin or source from where the selection is made
  query?: string; // The query text or the text that has been selected
  pageNumber?: number; // The page number where the text is selected
  selectedCoords?: number[][]; // The coordinates of the selected text
  coords?: Coords; // The Coords object representing the bounding coordinates of the selected text
}

// Exporting the default configuration, Coords class, and Selected class as a module.
export default {
  DEFAULT_CONFIG,
  Selected,
  Coords,
  EXLPdfServiceService, // This appears to be undefined in the given snippet. Make sure to define it before exporting.
};
