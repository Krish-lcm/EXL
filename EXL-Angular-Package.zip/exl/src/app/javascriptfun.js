import { EXLPdfServiceService } from './exlpdf-service-service.service';

export function setAppianValues(newValues) {
    let appianDocId;
    appianDocId = newValues.appianDocId;

    console.log("appianDocId : " + appianDocId);
    const payload = {
        documentId: newValues.appianDocId,
    };

    console.log("payload : " + payload);
    if (newValues.docAccessConnectedSystem != null) {
        getPDFDocumentFromAppian(newValues.docAccessConnectedSystem, payload);
    }

    function getPDFDocumentFromAppian(connectedSystem, payload) {
        console.log("getPDFDocumentFromAppian : ");
        Appian.Component.invokeClientApi(
            connectedSystem,
            'DocumentRetrieveClientApi',
            payload
        ).then(handleClientApiResponse, handleError);
    }

    function handleClientApiResponse(response) {
        console.log("handleClientApiResponse : ");

        var docData, docName;
        var payload = {};
        if (
            response.type == 'INVOCATION_SUCCESS' &&
            response.payload != undefined &&
            response.payload.hasOwnProperty('error')
        ) {
            Appian.Component.setValidations([
                'Error occured while retrieving the document, Please check if you have sufficient privileges to view it. ' +
                JSON.stringify(response.payload),
            ]);
        }

        if (
            response.type == 'INVOCATION_SUCCESS' &&
            response.payload != undefined &&
            response.payload.hasOwnProperty('docData')
        ) {
            console.log("INVOCATION_SUCCESS");
            console.log("response.payload.docName :" + response.payload.docName);

            payload = response.payload;
            docData = response.payload.docData;
            docName = response.payload.docName;
            // EXLPdfServiceService.setPDFContents(docData);
            // this.service.setPDFContents(docData);
            // service.setPDFContents(docData);
            //service.setPDFContents(docData);


        } else {
            Appian.Component.setValidations([
                'Unable to retrieve document from Appian, please check documentId',
                response.payload.error,
            ]);
            EXLPdfServiceService.setTestPDFContents();
        }
        //this.src = this.service.src;
        return response;
    }
    function handleError(handleResponse) {
        console.log("handleError : ");

        if (handleResponse.error && handleResponse.error[0]) {
            Appian.Component.setValidations([handleResponse.error]);
        } else {
            Appian.Component.setValidations(['An unspecified error occurred']);
        }
        return;
    }


}
