import { Component, Injectable, Input } from '@angular/core';
import {
  NgbCalendar,
  NgbDateAdapter,
  NgbDateParserFormatter,
  NgbDatepickerModule,
  NgbDateStruct,
} from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { JsonPipe } from '@angular/common';
import { formatDate } from '@angular/common';
import { TableComponent } from './table/table.component';
import { Selected } from './coordinate';
import { EXLPdfServiceService } from './exlpdf-service-service.service';
declare var Appian: any;
const monthNames = [
  '',
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec',
];
function padNumber(value: number | null) {
  if (!isNaN(value) && value !== null) {
    return `0${value}`.slice(-2);
  } 
  return '';
}

/**
 * This Service handles how the date is represented in scripts i.e. ngModel.
 */
@Injectable()
export class CustomAdapter extends NgbDateAdapter<string> {
  readonly DELIMITER = '-';

  fromModel(value: string | null): NgbDateStruct | null {
    if (value) {
      const date = value.split(this.DELIMITER);
      return {
        day: parseInt(date[0], 10),
        month: parseInt(date[1], 10),
        year: parseInt(date[2], 10),
      };
    }
    return null;
  }

  toModel(date: NgbDateStruct | null): string | null {
    // return date
    //   ? date.day + this.DELIMITER + date.month + this.DELIMITER + date.year
    //   : null;
    return date ?
        `${padNumber(date.day)}-${padNumber(date.month)}-${date.year || ''}` :
        '';
  }
}

/**
 * This Service handles how the date is rendered and parsed from keyboard i.e. in the bound input field.
 */
@Injectable()
export class CustomDateParserFormatter extends NgbDateParserFormatter {
  readonly DELIMITER = '-';

  parse(value: string): NgbDateStruct | null {
    if (value) {
      const date = value.split(this.DELIMITER);
      return {
        day: parseInt(date[0], 10),
        month: parseInt(date[1], 10),
        year: parseInt(date[2], 10),
      };
    }
    return null;
  }

  format(date: NgbDateStruct | null): string {
    // return date
    //   ? date.day + this.DELIMITER + date.month + this.DELIMITER + date.year
    //   : '';
    return date ?
    `${padNumber(date.day)}-${padNumber(date.month)}-${date.year || ''}` :
    '';
  }
}

@Component({
  selector: 'ngbd-datepicker-adapter',
  standalone: true,
  imports: [NgbDatepickerModule, FormsModule, JsonPipe],
  templateUrl: './datepicker-adapter.html',

  // NOTE: For this example we are only providing current component, but probably
  // NOTE: you will want to provide your main App Module
  providers: [
    { provide: NgbDateAdapter, useClass: CustomAdapter },
    { provide: NgbDateParserFormatter, useClass: CustomDateParserFormatter },
  ],
})
export class NgbdDatepickerAdapter {
  model1: string;
  model2: string;
  _eachField: any;
  _eachSection: any;
  @Input()
  set eachField(eachField: any) {
    this._eachField = eachField;
  }
  get eachField() {
    return this._eachField;
  }
  @Input()
  set eachSection(eachSection: any) {
    this._eachSection = eachSection;
  }
  get eachSection() {
    return this._eachSection;
  }

  constructor(
    private ngbCalendar: NgbCalendar,
    private exlService: EXLPdfServiceService,
    private dateAdapter: NgbDateAdapter<string>
  ) {}

  get today() {
    return this.dateAdapter.toModel(this.ngbCalendar.getToday())!;
  }

  bindDatetoModel(eachField: any) {
    let ret: any = undefined;
    ret = eachField.values.query;
    if (eachField.values.query != '' && eachField.values.query != null) {
      ret = formatDate(eachField.values.query, 'dd-MM-yyyy', 'en-US');
      this.dateAdapter.toModel(ret);
      return ret;
    }
  }
  getFieldValue(field: any, value: any) {
    var fieldValue = {
      field: field.name,
      query: value,
      pageNumber: (field.values.pageNumber =
        field.values.pageNumber === null ? 0 : field.values.pageNumber),
      origin: 'AUTO',
      xMin: (field.values.xMin =
        field.values.xMin === null ? 0 : field.values.xMin),
      xMax: (field.values.xMax =
        field.values.xMax === null ? 0 : field.values.xMax),
      yMin: (field.values.yMin =
        field.values.yMin === null ? 0 : field.values.yMin),
      yMax: (field.values.yMax =
        field.values.yMax === null ? 0 : field.values.yMax),
      type: (field.values.type =
        field.values.type === null ? '' : field.values.type),
      style: (field.values.style =
        field.values.style === null ? '' : field.values.style),
      disabled: (field.values.disabled =
        field.values.disabled === null ? '' : field.values.disabled),
      required: (field.values.required =
        field.values.required === null ? '' : field.values.required),
      accuracy: (field.values.accuracy =
        field.values.accuracy === null ? 0 : field.values.accuracy),
    };

    return fieldValue;
  }
  onDateChange(field: any, event: Event) {
    TableComponent._currentSelectItem = field;

    if (field.type === 'date') {
      let selecteddate: any = event;
      //if (selecteddate == '') selecteddate = undefined;

      const outputdate =
        selecteddate === '' ? '' : this.convertToDate(selecteddate);
      let dateField: Selected = {
        query: outputdate,
      };
      this.update(dateField);
      document.getElementById('lblhidden').innerHTML = field.name;

      var fieldValue = this.getFieldValue(field, outputdate);

      Appian.Component.saveValue('onChangeLast', {
        name: field.name,
        fieldDetails: field,
        newValue: fieldValue,
      });
    }
  }
  onFocus(event: any) {
    TableComponent._currentSelectItem = event;
    //this.exlService.clearOldRectangles();
    //if no rows and pageNumber available in selected  field ,Rectangle cannot  be drawn.
    if (event.values == undefined) {
      //  return;
    } else {
      //cordinated are availabe, hence rectangle can be  draw.
      let focusField: Selected = {
        query: event.values.query,
        pageNumber: event.values.pageNumber,
        origin: 'SELECTED',
        selectedCoords: [[]],
        coords: {
          xMin: event.values.xMin == undefined ? null : event.values.xMin,
          yMin: event.values.yMin == undefined ? null : event.values.yMin,
          xMax: event.values.xMax == undefined ? null : event.values.xMax,
          yMax: event.values.yMax == undefined ? null : event.values.yMax,
        },
      };
      if (
        event.values.pageNumber != undefined ||
        event.values.pageNumber != null
      ) {
        this.exlService.clearOldRectangles();
       this.exlService.drawRectangle(focusField);
       
      }
    }
  }
  public convertToDate(inputString: string): string {
    try {
      let monthN:any=inputString.split('-')[1];
      let date = new Date(inputString);

      let day = inputString.split('-')[0]; //date.getDate().toString().padStart(2, '0');


const date1 = new Date();
  date1.setMonth(monthN - 1);
      let month = date1.toLocaleString('default', { month: 'short' });//this.getMonthName[inputString.split('-')[1]]; //date.toLocaleString('default', { month: 'short' });

      let year = inputString.split('-')[2]; //date.getFullYear();

      return `${day}/${month}/${year}`;
    } catch (error) {
      console.error(
        'An error occurred while converting the date string:',
        error
      );

      return '';
    }
  }
   getMonthName(monthNumber:any) {
    
    const date = new Date();
    date.setMonth(monthNumber - 1);
  
    return date.toLocaleString('en-US', {
      month: 'long',
    });
  }
  update(val: Selected) {
    if (TableComponent._currentSelectItem.type === 'date') {
      TableComponent._currentSelectItem.query = val.query;
      for (let i = 0; i < this._eachSection.fields.length; i++) {
        if (
          this._eachSection.fields[i].name ===
          TableComponent._currentSelectItem.name
        ) {
          this._eachSection.fields[i].values.query = val.query;
        }
      }
    }
  }
}
