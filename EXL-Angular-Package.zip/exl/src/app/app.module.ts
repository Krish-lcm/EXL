import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgxExtendedPdfViewerModule } from 'ngx-extended-pdf-viewer';
import { SectionComponent } from './section/section.component';
import { FieldsComponent } from './fields/fields.component';
import { TableComponent } from './table/table.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import '@angular/localize/init';
import {
  AlertModule,
  SharedModule,
  NavModule,
  TabsModule,
  GridModule,
  FormModule,
} from '@coreui/angular';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { LuxonModule } from 'luxon-angular';
import { DropdownModule } from 'primeng/dropdown';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { TabViewModule } from 'primeng/tabview';
import { InputTextModule } from 'primeng/inputtext';
import { FieldsetModule } from 'primeng/fieldset';
import { PanelModule } from 'primeng/panel';
import { TableModule } from 'primeng/table';
import { AccordionModule } from 'primeng/accordion';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CardModule } from 'primeng/card';
import { InputNumberModule } from 'primeng/inputnumber';
import { CalendarModule } from 'primeng/calendar';
import { NgbdDatepickerAdapter } from "./datepicker-adapter";



@NgModule({
    declarations: [
        AppComponent,
        SectionComponent,
        FieldsComponent,
        TableComponent
    ],
    providers: [],
    bootstrap: [AppComponent],
    imports: [
        BrowserModule,
        CardModule,
        FlexLayoutModule,
        TableModule,
        FieldsetModule,
        PanelModule,
        InputTextModule,
        TabViewModule,
        AutoCompleteModule,
        DropdownModule,
        LuxonModule,
        AppRoutingModule,
        NgxExtendedPdfViewerModule,
        HttpClientModule,
        AlertModule,
        AccordionModule,
        NavModule,
        FormModule,
        GridModule,
        TabsModule,
        BrowserAnimationsModule,
        FormsModule,
        SharedModule,
        InputNumberModule,
        CalendarModule,
        FontAwesomeModule,
        NgbdDatepickerAdapter,
        
    ]
})
export class AppModule {}
