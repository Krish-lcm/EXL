// This class represents a set of coordinates with minimum and maximum values for both x and y axes.
export class Coordinate {
  xMin: number;
  xMax: number;
  yMax: number;
  yMin: number;
}

// This class represents a selection with optional properties such as origin, query, page number, selected coordinates, and an instance of the Coordinate class.
export class Selected {
  origin?: string; // Origin of the selection (optional)
  query?: string; // Query associated with the selection (optional)
  pageNumber?: number; // Page number of the selection (optional)
  selectedCoords?: number[][]; // Array of selected coordinates (optional)
  coords?: Coordinate; // Instance of Coordinate class to store coordinate data (optional)
}

// This class represents a dropdown value with optional query and value properties.
export class DropDownVal {
  query?: string; // Query associated with the dropdown (optional)
  value?: string; // Value of the dropdown selection (optional)
}
