
export interface ruleProps {

    controls: string[];
    values: string[];
    name:boolean
}
export interface ruleStyleProps {

    controls: string[];
    values: string[];
    styleProperties:string
}

export interface masterListProps {

    controls: string[];
    values: string[];
    name:string
   
}


export interface Rule {

    disabled :ruleProps[]
    visibility:ruleProps[]
    style :ruleStyleProps[]
    masterList:masterListProps[]
    required:ruleProps[]
   
}

export interface  brokerData{
    brokerCode:string
    brokerPseudoCode:string
    brokerName:string
}

export interface CascadingRule {
    Filters: Controls;
    cascadingList:brokerData[]
    controls:Controls

}

export interface Controls {

    masterList:string
    controlName:string

}
