import { AfterViewInit, Component, Input } from '@angular/core';
import { Subject } from 'rxjs';
import { Selected, DropDownVal } from '../coordinate';
import { EXLPdfServiceService } from '../exlpdf-service-service.service';
import { Rule, masterListProps } from '../rule';
declare var Appian: any;

@Component({
  selector: 'app-fields',
  templateUrl: './fields.component.html',
  styleUrls: ['./fields.component.css'],
})
export class FieldsComponent implements AfterViewInit {
  _eachMileStone: any;
  _idx: number;
  _masterList: any;
  defaultSelecText: string = '-- Select --';
  defaultSelectValue: string = undefined;
  public static _currentSelectItem: any;
  public visible: boolean = false;
  PROPTYPE = {
    DISABLED: 0,
    VISIBILITY: 1,
    STYLE: 2,
    REQUIRED: 3,
    MASTERLIST: 4,
  };
  controlMap = new Map<string, string>();
  stylelMap = new Map<string, string>();
  masterValueMap = new Map<string, DropDownVal[]>();
  selectedValues = new Map<string, DropDownVal[]>();

  constructor(private exlService: EXLPdfServiceService) {}
  ngAfterViewInit(): void {
    this.addMasterListtoMap();
  }

  /**
   * Default placegolder values add to the list.This is the first items of the
   * dropdown
   * @param field
   * @param arr
   */
  addPlaceholdetoArray(field: any, arr: DropDownVal[]) {
    if (field.placeholder === undefined || field.placeholder == null) {
      let defaultOpts: DropDownVal = {
        query: this.defaultSelecText,
        value: this.defaultSelectValue,
      };
      arr.unshift(defaultOpts);
    } else {
      let defaultOpts: DropDownVal = {
        query: this.defaultSelecText,
        value: this.defaultSelectValue,
      };
      arr.unshift(defaultOpts);
    }
  }

  /**
   * To populate drop downs .Dropdown values are taken from masterValueMap
   * map
   * @param eachField
   * @returns
   */
  getOptions(eachField: any) {
    let values: DropDownVal[] = undefined;
    for (let i = 0; i <= this._eachMileStone.fields.length; i++) {
      if (this._eachMileStone.fields[i].name === eachField.name) {
        values = this.masterValueMap.get(eachField.name);
        break;
      }
    }

    return values;
  }

  fieldshowhide(showLabel: boolean) {
    if (showLabel != null && showLabel != undefined) {
      return (this.visible = showLabel);
    } else {
      return (this.visible = false);
    }
  }
  @Input()
  set masterList(list: any) {
    this._masterList = list;
  }
  get masterList() {
    return this._masterList;
  }
  @Input()
  set eachMilestone(eachMilestone: any) {
    this._eachMileStone = eachMilestone;
  }
  get eachMilestone() {
    return this._eachMileStone;
  }
  @Input()
  set selectIdx(selectIdx: any) {
    this._idx = selectIdx;
    this.ngAfterViewInit();
  }
  get selectIdx() {
    return this._idx;
  }

  @Input() notifier: Subject<Selected>;
  value: Selected;

  ngOnInit() {
    this.notifier.subscribe((data) => (this.value = data));
  }

  /**
   * Handle focus event
   * @param event = _eachSection.field
   * @returns
   */

  onFocus(event: any) {
    
    //store the selected field type
    FieldsComponent._currentSelectItem = event;
    //this.exlService.clearOldRectangles();
    //if no rows and pageNumber available in selected  field ,sRectangle cannot  be drawn.
    if (event.values == undefined || event.values.pageNumber == undefined) {
      return;
    } else {
      //cordinated are availabe, hence rectangle can be  draw.
      let focusField: Selected = {
        query: event.values.query,
        pageNumber: event.values.pageNumber,
        origin: 'SELECTED',
        selectedCoords: [[]],
        coords: {
          xMin: event.values?.xMin,
          yMin: event.values?.yMin,
          xMax: event.values?.xMax,
          yMax: event.values?.yMax,
        },
      };
      this.exlService.clearOldRectangles();
     this.exlService.drawRectangle(focusField);
     
     
    }
  }

  /**
   * Bind the Json extracted text box values to model. This is used  to  configure
   * ngModel attribute
   *
   * @param eachField  - Element Field attributes
   * @returns
   */
  bindtoModel(eachField: any) {
    let ret: string = undefined;
    if (eachField.type === 'text') {
      for (let i = 0; i < this._eachMileStone.fields.length; i++) {
        if (this._eachMileStone.fields[i].name === eachField.name) {
          ret = this._eachMileStone.fields[i].values.query;
        }
      }
    } else if (eachField.type === 'date') {
      for (let i = 0; i < this._eachMileStone.fields.length; i++) {
        if (this._eachMileStone.fields[i].name === eachField.name) {
          //  ret = this.formatDate(this._eachMileStone.fields[i].query)
          break;
        }
      }
    }
    return ret;
  }
  /**
   * Notify model When appComponent capture PDF changes
   * @param val - Selected values  from PDF ( value and cordinated)
   */
  triggerModelChanegs() {
    this.update(this.value);
  }

  /*
     update model with the changes .chanegs will include direct text box entries
     and selected text  values and cordinated  from PDF
  */

  update(val: Selected) {
    if (
      FieldsComponent._currentSelectItem.type === 'text' ||
      FieldsComponent._currentSelectItem.type === 'number'
    ) {
      FieldsComponent._currentSelectItem.query = val.query;

      for (let i = 0; i < this._eachMileStone.fields.length; i++) {
        if (
          this._eachMileStone.fields[i].name ===
          FieldsComponent._currentSelectItem.name
        ) {
          this._eachMileStone.fields[i].values.query = val.query;
          if (val.query == null || val.query == undefined) {
            this._eachMileStone.fields[i].values.isSelected = false;
          } else this._eachMileStone.fields[i].values.isSelected = true;
        }
      }
    }
    if (FieldsComponent._currentSelectItem.type === 'date') {
      FieldsComponent._currentSelectItem.query = val.query;
      for (let i = 0; i < this._eachMileStone.fields.length; i++) {
        if (
          this._eachMileStone.fields[i].name ===
          FieldsComponent._currentSelectItem.name
        ) {
          this._eachMileStone.fields[i].values.query = val.query;
        }
      }
    } else if (FieldsComponent._currentSelectItem.type === 'select') {
      for (let i = 0; i < this._eachMileStone.fields.length; i++) {
        if (
          this._eachMileStone.fields[i].name ===
          FieldsComponent._currentSelectItem.name
        ) {
          this._eachMileStone.fields[i].values.query = val.query;

          this._eachMileStone.fields[i].values.pageNumber = val.pageNumber;
          break;
        }
      }
      FieldsComponent._currentSelectItem.values.query = val.query;
    }
  }

  getFieldValue(field: any, value: any) {
    var fieldValue = {
      field: field.name,
      query: value,
      pageNumber: (field.values.pageNumber =
        field.values.pageNumber === null ? 0 : field.values.pageNumber),
      origin: 'AUTO',
      xMin: (field.values.xMin =
        field.values.xMin === null ? 0 : field.values.xMin),
      xMax: (field.values.xMax =
        field.values.xMax === null ? 0 : field.values.xMax),
      yMin: (field.values.yMin =
        field.values.yMin === null ? 0 : field.values.yMin),
      yMax: (field.values.yMax =
        field.values.yMax === null ? 0 : field.values.yMax),
      type: (field.values.type =
        field.values.type === null ? '' : field.values.type),
      style: (field.values.style =
        field.values.style === null ? '' : field.values.style),
      disabled: (field.values.disabled =
        field.values.disabled === null ? '' : field.values.disabled),
      required: (field.values.required =
        field.values.required === null ? '' : field.values.required),
      accuracy: (field.values.accuracy =
        field.values.accuracy === null ? 0 : field.values.accuracy),
    };

    return fieldValue;
  }

  /*
   Input text box value chnages are saved  to model
  */
  onTextChange(field: any, event: any) {
    
    if (event != null) {
      if(field.values.query==event.target.value){
       // this.onFocus(field);
        return;
      }
    }
    if (field.type === 'text') {
      let selectTextVal: any =event.target.value; //event;//event.target.value;
      if (selectTextVal == '') selectTextVal = undefined;
      let textField: Selected = {
        query: selectTextVal,
      };
      
      this.update(textField);
      var fieldValue = this.getFieldValue(field, selectTextVal);

      Appian.Component.saveValue('onChangeLast', {
        name: field.name,
        fieldDetails: field,
        newValue: fieldValue,
      });
    }
  }

  /*
  Date field chanegs are saved to model
  */
  onDateChange(field: any, event: Event) {
    FieldsComponent._currentSelectItem = field;

    if (field.type === 'date') {
      const selecteddate: any = event;
      let dateField: Selected = {
        query: selecteddate,
      };
      this.update(dateField);
      Appian.Component.saveValue('onChangeLast', {
        name: field.name,
        fieldDetails: field,
        newValue: selecteddate,
      });
    }
  }

  updateModelwithMasterList(
    obj: masterListProps,
    fieldName: string,
    reset: boolean,
    type: number
  ) {
    for (let i = 0; i < this._eachMileStone.fields.length; i++) {
      if (this._eachMileStone.fields[i].name === fieldName) {
        if (type == this.PROPTYPE.MASTERLIST) {
          if (!reset) {
            this.controlMap.set(
              fieldName,
              this._eachMileStone.fields[i].masterListValue
            );
            this._eachMileStone.fields[i].masterListValue = obj.name;
          } else {
            this.controlMap.set(
              fieldName,
              this._eachMileStone.fields[i].masterListValue
            );
            this._eachMileStone.fields[i].masterListValue = obj.name;
          }
        }
        break;
      }
    }
  }
  processMasterListRule(
    obj: masterListProps,
    selectedValue: string,
    type: number
  ) {
    if (type === this.PROPTYPE.MASTERLIST) {
      obj.controls.forEach((element) => {
        if (obj.values.includes(selectedValue)) {
          const masterListData = this._masterList[obj.name];

          let displayTexts = masterListData?.text;

          let displayValues = masterListData?.value;

          if (!displayTexts) {
            displayTexts = masterListData;

            displayValues = masterListData;
          }

          const arr = displayTexts.map((text, index) => ({
            query: text,

            value: displayValues[index],
          }));

          this.addPlaceholdetoArray(obj.controls[0], arr);

          this.masterValueMap.set(obj.controls[0], arr);
        } else {
          this.updateModelwithMasterList(obj, element, true, type);
        }
      });
    }
  }
  applyRule(field: any, selectedValue: string) {
    if (field.rule) {
      field.rule.forEach((element) => {
        const jsonStr = JSON.stringify(element);
        let obj: Rule = JSON.parse(jsonStr);

        //masterList
        if (obj.hasOwnProperty('masterList')) {
          obj.masterList.forEach((n) => {
            this.processMasterListRule(
              n,
              this.getSelectedItemValue(selectedValue),
              this.PROPTYPE.MASTERLIST
            );
          });
        }
      });
    }
  }
  /*
     Drop down values are are saved to model
   */
  onSelectChange(field: any, event: Event) {
    FieldsComponent._currentSelectItem = field;

    if (field.type === 'select') {
      let selectedItem: any = event;
      if (selectedItem == '' || selectedItem == '-Select-')
        selectedItem = undefined;
      let selectField: Selected = {
        query: selectedItem,
        pageNumber: field.values.pageNumber,
      };

      this.update(selectField);
      if (field.rule) this.applyRule(field, selectedItem);
      var fieldValue = this.getFieldValue(field, selectedItem);
      Appian.Component.saveValue('onChangeLast', {
        name: field.name,
        fieldDetails: field,
        newValue: fieldValue,
      });
    }
  }

  getSelectedItemValue(selectedItem: string): string | undefined {
    return selectedItem === 'Yes'
      ? '1'
      : selectedItem === 'No'
      ? '0'
      : undefined;
  }

  getEachFieldValue(selectedItem: string): string | undefined {
    let a = selectedItem == '1' ? 1 : selectedItem == '0' ? 0 : selectedItem;

    return selectedItem == '1'
      ? 'Yes'
      : selectedItem == '0'
      ? 'No'
      : selectedItem;
  }

  //Test function
  onClick() {
    alert('onClick');
    alert(`${FieldsComponent._currentSelectItem.query}:
    ${FieldsComponent._currentSelectItem.values.xMax} :
    ${FieldsComponent._currentSelectItem.values.xMin} : 
    ${FieldsComponent._currentSelectItem.values.yMax} :
    ${FieldsComponent._currentSelectItem.values.yMin}`);
  }

  showToolTip(field: any): boolean {
    let nRet: boolean = false;
    let fieldName = field.label;
    const labels = this._eachMileStone.fields.filter(
      (e) => e.label == field.label
    );

    if (labels.length == 1) {
      if (field.values.query == null || field.values.query === undefined) {
        nRet = true;
      }
    }
    //ex:if two or more broker codes are available
    if (labels.length >= 2) {
      for (let j = 0; j < labels.length; j++) {
        if (
          labels[j].values.query == null ||
          labels[j].values.query == undefined
        ) {
          nRet = true;
        }
      }
    }
    return nRet;
  }

  getValidatedMessage(field: any): string {
    let nRet: string = undefined;
    if (field.type === 'text') {
      for (let i = 0; i < this._eachMileStone.fields.length; i++) {
        if (this._eachMileStone.fields[i].name === field.name) {
          nRet = 'Value can not be blank for ' + field.label;
          break;
        }
      }
    }

    if (field.type === 'date') {
      for (let i = 0; i < this._eachMileStone.fields.length; i++) {
        if (this._eachMileStone.fields[i].name === field.name) {
          nRet = 'Value can not be blank for ' + field.label;
          break;
        }
      }
    }

    if (field.type === 'select' || field.type == 'searchableDropdown') {
      for (let i = 0; i < this._eachMileStone.fields.length; i++) {
        if (this._eachMileStone.fields[i].name === field.name) {
          nRet = 'Select 1 value  for  ' + field.label;
          break;
        }
      }
    }
    return nRet;
  }

  TestMe() {
    const json = JSON.stringify(Object.fromEntries(this.masterValueMap));

    alert(json);
  }
  /**
   * Masterlist  items added to the internal hash map.
   */

  addMasterListtoMap() {
    this._eachMileStone.fields.forEach((field) => {
      if (field.type === 'select') {
        if (this._masterList != undefined) {
          let masterListValue = this._masterList[field.masterListValue];
          let displayTexts = masterListValue?.text || masterListValue;
          let displayValues = masterListValue?.value || masterListValue;

          if (displayTexts && displayValues) {
            let arr: DropDownVal[] = displayTexts.map((text, index) => ({
              query: text,
              value: displayValues[index],
            }));

            this.addPlaceholdetoArray(field, arr);
            this.masterValueMap.set(field.name, arr);
          }
        }
      }
    });
  }
}
