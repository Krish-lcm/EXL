import { Injectable, Pipe, PipeTransform } from '@angular/core';
import { LuxonModule } from 'luxon-angular';
import { DatePipe } from '@angular/common';

// import {
//   DateTime,
//   Duration,
//   FixedOffsetZone,
//   IANAZone,
//   Info,
//   Interval,
//   InvalidZone,
//   Settings,
//   SystemZone,
//   VERSION,
//   Zone,
// } from 'luxon';
@Pipe({
  name: 'customDateFormat',
})
@Injectable({
  providedIn: 'root',
})
export class Common {
  public _selectedItem: any[] = [];
  public _inputTextVal: String;
  public _inputDateVal: String;
  public _dropdownValues: any[] = [];
  public _masterListElement: any[] = [];

  formatDate(value: string) {
    var datePipe = new DatePipe('en-US');
    // value = datePipe.transform(value, 'dd-mm-yyyy');
    value = datePipe.transform(value, 'yyyy-MM-dd');
    //  console.log('Date :' + value);
    this._inputDateVal = value;
    return value;
  }

  //onChange(deviceValue: any, field: string) {
    public onChange(deviceValue: any, field: string): void {

    this._selectedItem = deviceValue.value;
    //alert(this._selectedItem);
      //console.log(field && " : "&&  this._selectedItem);
    //Appian.Component.saveValue("onChange", field);
  }

  initializeSelect(field: any, indexVal: number, list: any) {

    var displayTexts = [];
    var displayValues = [];
    var placeholderAppendText = [];
    var placeholderAppendValue = [];
    var placeholderText = '-- Select --';
    // No Master List Given */

    if (typeof field.masterListValue == 'undefined') {
      return true;
    }
    // Check if Separate Text and Values are given
    // If text is present in the master list then use it
    displayTexts =list[field.masterListValue].text;
    if (typeof displayTexts == 'undefined' || displayTexts == null) {
      displayTexts = list[field.masterListValue];
      displayValues = list[field.masterListValue];
    } else {
      displayTexts = list[field.masterListValue].text;
      displayValues = list[field.masterListValue].value;
      /* Check if text and values, both arrays have same length */
      //   if (displayTexts.length !== displayValues.length) {
      //     var err = {
      //       invalid: true,
      //       message:
      //         'text & value length mismatch in given master list : ' +
      //         field.masterListValue,
      //     };

      //     return err;
      //   }
    }

    if (field.hasOwnProperty('placeholder') && field.placeholder != null) {
      placeholderAppendText = [field.placeholder].concat(displayTexts);
      placeholderAppendValue = [''].concat(displayValues);
      displayValues = placeholderAppendValue;
      displayTexts = placeholderAppendText;
    } else {
      placeholderAppendText = [placeholderText].concat(displayTexts);
      placeholderAppendValue = [''].concat(displayValues);
      displayValues = placeholderAppendValue;
      displayTexts = placeholderAppendText;
    }

    if (field.type == 'select') {
      this.bindSelect(displayTexts, displayValues, indexVal, field);
    } else if (field.type == 'multiselect') {
    }

    return true;
  }

  bindSelect(displayTexts, displayValues, index, field) {
    var selectedValue = displayValues[0];
    var pageNumber = 0;
    var origin = 0;
    var xMin = 0;
    var xMax = 0;
    var yMin = 0;
    var yMax = 0;
    var fieldName = field.name;
    var elementId = fieldName + '_' + index;
    var booleanVal = ['0', '1'];

    var dropDownVal = [];
    /* Get Parameters of selected value */
    if (
      field.hasOwnProperty('rows') &&
      field.rows[0].hasOwnProperty('isSelected')
    ) {
      var row = field.rows[0];

      if (displayValues.indexOf(row.query) > -1 && row.isSelected) {
        selectedValue = row.query;
        this._selectedItem[fieldName] = selectedValue;
        pageNumber = row.pageNumber;
        origin = row.origin;
        xMin = row.xMin;
        xMax = row.xMax;
        yMin = row.yMin;
        yMax = row.yMax;
      }
    }

   
    var flagVal: boolean;
    if (this.isInArray(selectedValue.query, booleanVal)) {
      flagVal = true;
    } else {
      flagVal = this.isInArray(selectedValue.query, displayValues);
    }

    for (var i = 0; i < displayTexts.length; i++) {
      if (i === 0 && flagVal == false) {
        selectedValue = true;
        //$scope.selectedVal[fieldName].query = displayValues[i];
      } else {
        selectedValue = false;
      }

      dropDownVal[i] = {
        query: displayTexts[i],
        value: displayValues[i],
        pagenumber: pageNumber,
        orgin: origin,
        xMin: xMin,
        xMax: xMax,
        yMin: yMin,
        yMax: yMax,
        isSelected: selectedValue,
       // isSelected: $scope.isValueSelected(selectedValue, displayValues[i])
      };
    }
   
    this._dropdownValues[fieldName] = dropDownVal;
    //this._masterListElement[fieldName] = elementId;
    return this._dropdownValues, this._masterListElement;
  }

  isInArray(value: any, array: any) {
    return array.indexOf(value) > -1;
  }

  bindControlValues(eachField: any, index: number, masterlist: any) {
    let type: string = eachField.type;
    switch (type) {
      case 'text':
        //return (this._inputTextVal = eachField.query);
        return (this._selectedItem[eachField.name] = eachField.query);
      case 'date':
        //return (this._inputDateVal = this.formatDate(eachField.query));
        return (this._selectedItem[eachField.name] = this.formatDate(
          eachField.query
        ));
      case 'select':
        return (
          this.initializeSelect(eachField, index, masterlist),
          this._selectedItem[eachField.name]
        );

      default:
        //console.log('No such type exists!');
        break;
    }
  }

  saveInputTypeValue(field: any, value: any) {
    if (field.type != 'select' && field.type != 'multiselect') {
      if (
        typeof field == 'undefined' ||
        field == null ||
        typeof value == 'undefined' ||
        value == null
      ) {
        return;
      }
    } else {
      if (typeof field == 'undefined' || field == null) {
        return;
      }
    }

    // Specific Code for Select/Multiselect
    if (field.type == 'select' || field.type == 'multiselect') {
    }
    // General Code continues

    // Get the updated Value in correct format
    var fieldValue = this.getFieldValue(field, value);
  }
  convertObjectToAppianArray(data: any) {
    var arr = [];
    Object.keys(data).forEach(function (each) {
      if (Array.isArray(data[each])) {
        for (var i = data[each].length - 1; i >= 0; i--) {
          arr.push(data[each][i]);
        }
      } else {
        arr.push(data[each]);
      }
    });

    return arr;
  }
  getFieldValue(field: any, value: any) {
    // Blank Place holder for value
    var fieldValue = {
      field: field.name,
      query: '',
      pageNumber: 0,
      origin: 'AUTO',
      xMin: 0.0,
      xMax: 0.0,
      yMin: 0.0,
      yMax: 0.0,
    };
    // Sanitize query
    if (typeof value.query == 'undefined' || value.query == null) {
      value.query = '';
    }
    // Update the placeholder with values. Whatever is missing will have default values from placeholder
    fieldValue = Object.assign(fieldValue, value);
    return fieldValue;
  }
  isObjectEmpty(obj: any) {
    for (var name in obj) {
      return false;
    }
    return true;
  }

  filterObject = (obj: any, filter: any, filterValue: any) =>
    Object.keys(obj).reduce(
      (acc, val) =>
        obj[val][filter] === filterValue
          ? {
              [val]: obj[val],
            }
          : acc,
      {}
    );
}

export default {
  Common,
};
